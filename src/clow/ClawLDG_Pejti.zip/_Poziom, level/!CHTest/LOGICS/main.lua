function OnMapLoad()
	local init = MapAnisFolder(LoadFolder("LEVEL12_ANIS_STALACTITE"),"LEVEL_STALACTITE")
	
end
