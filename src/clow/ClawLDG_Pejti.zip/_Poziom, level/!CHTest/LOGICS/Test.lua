function main(self)
	if self.State == 0 then
		self.State = 1
		self.CrumblingPegFromLogic1 = CreateObject {x=965, y=4450, z=1000, logic="CrumblingPeg", image="LEVEL_CRUMBLINGPEG"}
	end
end