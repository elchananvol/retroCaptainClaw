local variableA = 5

function init(self)
	self.HitRect = {-32,-32,32,32}
	self.HitTypeFlags = ObjectType.Special
	--CODE
end

function main(self)
	if self.State == 0 then
		self.State = 1	--self.State = variableA
		self.AttackRect = {-32,-32,32,32}
		self.AttackTypeFlags = ObjectType.Player
		--CODE
	end
end

function attack(self)
		--CODE
end

function hit(self)
		--CODE
end