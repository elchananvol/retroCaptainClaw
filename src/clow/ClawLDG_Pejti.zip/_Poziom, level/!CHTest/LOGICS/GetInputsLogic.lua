function main(self)
	TextOut(GetInput())
end