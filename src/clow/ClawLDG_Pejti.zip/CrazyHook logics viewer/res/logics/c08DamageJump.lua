function main(self)
	if self.State == 0 then
		self.State = 1
		self.AttackRect = {-32,-32,32,32}
		self.AttackTypeFlags = ObjectType.Player
	end
end
function attack(self)
	TextOut("Aaah")
	ClawTakeDamage(25)
	ClawJump(100)
	self:Destroy()
end