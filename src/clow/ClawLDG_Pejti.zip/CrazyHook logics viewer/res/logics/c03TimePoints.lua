function main(self)
	if self.State == 0 and GetTicks() > 5000 then	--5 seconds
		self.State = 1
		GetClaw().Score = GetClaw().Score + 666		--also negative value
		GetClaw().Health = GetClaw().Health + 123	--also negative value
	end
end