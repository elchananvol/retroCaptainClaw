function main(self)
	if self.State == 0 then
		self.State = 1
		self.AttackRect = {-20, -20, 20, 20}
		self.AttackTypeFlags = ObjectType.Player
		self.amplitude = 15
		self.MovingTreasure = CreateObject {x=self.X, y=self.Y, z=5000, logic="TreasurePowerup", image="GAME_TREASURE_GOLDBARS"}
		self.startY = self.MovingTreasure.Y
	end
	if self.State == 1 then
		self.State = 2
		self.MovingTreasure.Y = self.startY + self.amplitude*math.sin(GetTicks()*0.0100)	--bouncing
		self.MovingTreasure.GlitterPointer.Y = self.MovingTreasure.Y	--glitter bouncing
	end
	if self.State == 2 then
		self.State = 1
	end
end