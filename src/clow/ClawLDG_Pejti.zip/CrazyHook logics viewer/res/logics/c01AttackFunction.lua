function main(self)
	if self.State == 0 then
		self.State = 1
		self.AttackRect = {-32,-32,32,32}
		self.AttackTypeFlags = ObjectType.Player
	end
end
function attack(self)
	TextOut("Simple text")
	PlaySound("GAME_COIN")
	self.NewObject = CreateObject {x=self.X, y=self.Y, z=self.Z, logic="CrumblingPeg", image="LEVEL_CRUMBLINGPEG"}
	self:Destroy()
end