function main(self)
	if self.State == 0 then
		BearSailor(self)
		self:SetImage("CUSTOM_XMASBEAR")
	else
		BearSailor(self)
	end
end