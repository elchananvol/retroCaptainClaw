function init(self)
	self.officerHealth = self.Health	--setting new variable for health
end
function main(self)
	if self.State == 0 then
  		Officer(self)
  		self.Health = self.officerHealth	--setting new health
	else
  		Officer(self)	--creating enemy
	end
end