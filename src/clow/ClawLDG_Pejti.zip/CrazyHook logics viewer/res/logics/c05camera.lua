function main(self)
	if self.State == 0 and GetClaw().X > self.X + 50 then
		self.State = 1
		CameraToPoint(self.X,self.Y)
	end
	if self.State == 1 and GetClaw().X > self.X + 150 then
		self.State = 2
		CameraToObject(GetObject(29))	--object ID
	end
	if self.State == 2 and GetClaw().X > self.X + 250 then
		self.State = 3
		CameraToClaw()
	end
end