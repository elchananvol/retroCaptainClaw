function main(self)
	if self.State == 0 then
		self.State = 1
	local flags = ffi.new("Flags_t")	--setting flags
	flags.AlwaysActive = true			--
		self.Sky = CreateObject {x=320, y=240, z=-9000, logic="BackgroundLogic", image="CUSTOM_SKY", Flags=flags}
	end
end