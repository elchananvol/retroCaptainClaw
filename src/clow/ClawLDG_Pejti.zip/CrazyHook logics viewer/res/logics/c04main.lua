function OnMapLoad()
	PlayerData().PistolAmmo = 50
	PlayerData().MagicAmmo = 50
	PlayerData().TNTAmmo = 50
	PlayerData().Lives = 10
end
