function main(self)
	if self.State == 0 then
		self.State = 1
		self.HitRect = {-32,-32,32,32}
		self.HitTypeFlags = ObjectType.Player
	end
end
function hit(self)
	TextOut("Simple text")
	PlaySound("GAME_COIN")
	self.NewObject = CreateObject {x=self.X, y=self.Y, z=self.Z, logic="TogglePeg", image="LEVEL_PEG"}
	self:Destroy()
end